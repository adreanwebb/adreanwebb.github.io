function [ stokesMagnitudeArray, stokesDirectionArray ] = ...
    fnc_stokes_full_components_depth( spec2dArrayNd, freqVector, ...
    deltaFreqVector, thetaVector, deltaThetaValue, depthVector, nullValue )

%% CALCULATE 2DH-SD MAGNITUDE AND DIRECTION: 
% This function uses 2D wave spectra to calculate the Stokes drift (SD)
% magnitude and direction at some specified depth for an arbitrary number
% of spatial and temporal dimensions. Created by Adrean Webb.
%
% Requires: nothing.
%
% function [ stokesMagnitudeArray, stokesDirectionArray ] = ...
%   fnc_stokes_full_components_depth( spec2dArrayNd, freqVector, ...
%   deltaFreqVector, thetaVector, deltaThetaValue, depthVector, nullValue )
%
% In:   'spec2dArrayNd'     2D directional-frequency spectra with 
%                             dimensions [nFreq nTheta ... ...].
%       'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin. 
%       'thetaVector'       Periodic theta bin vector in radians (centered).
%                             [theta1:deltaTheta:theta1+2pi-deltaTheta]
%       'deltaThetaValue'   Delta theta value in radians (constant).
%       'depthVector'       Depth is defined as ABS(z).
%       'nullValue'         Specifies null return value for empty spectrum
%                             locations (variable input; default value 0).
%
% Out:  'stokesMagnitudeArray'     2Dh-SD magnitude with dimensions 
%                                    [nDepth ... ...].      
%       'stokesDirectionArray'     2Dh-SD direction with dimensions
%                                    [nDepth ... ...].
%
% Version: 1.1 [2012/11/06] -   Expanded capability to handle an arbitrary 
%                                 number of spatial and temporal dimensions. 
%                                 The script columnizes the extra dimensions in
%                                 the 1D spectra and reshapes output to match.
%          1.2 [2012/11/06] -   Changed script to run on older versions of
%                                 Matlab less than 2011b.
%          1.3 [2014/07/19] -   Fixed a bug introduced in Version 1.1 and added
%                                 null specification functionality.


%% 1. CHECK AND CONVERT INPUT IF NECESSARY.

if verLessThan('matlab','7.13')
    nargchk(6,7,nargin);
else    
    narginchk(6,7);
end

subfnc_check_column_vector( freqVector, deltaFreqVector, thetaVector, ...
    depthVector );

subfnc_check_freq_cutoff( freqVector, deltaFreqVector );

nFreq = length(freqVector); nTheta = length(thetaVector);

[ flgSpec2d, nDimension ] = subfnc_check_orientation( spec2dArrayNd, nFreq, ...
    nTheta );

[ spec2dArray3d, rebuildVector ] = subfnc_reduce_dimension( spec2dArrayNd, ...
    3, nDimension, flgSpec2d );


%% 2. PRELIMINARY INITIALIZATION AND CALCULATIONS.

G = 9.81;

nDepth = size(depthVector,1); nPoint = size(spec2dArray3d,3);

stokesSumStaticMatrix = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector, depthVector, G );
stokesTailStaticVector = subfnc_SD_tail_static( freqVector(end,1), ...
    depthVector, G );


%% 3. INTEGRATE FREQUENCY COMPONENT.

stokesStepArray = zeros(nTheta,nDepth,nPoint);
for indPoint=1:nPoint
    for indDepth=1:nDepth
        for indTheta=1:nTheta
            stokesStepArray(indTheta,indDepth,indPoint) = ...
                sum( stokesSumStaticMatrix(:,indDepth) .* ...
                spec2dArray3d(:,indTheta,indPoint) ) + ...
                stokesTailStaticVector(indDepth) * ...
                spec2dArray3d(end,indTheta,indPoint);
        end
    end
end


%% 4. INTEGRATE THETA COMPONENT.

stokesDepthXMatrix = zeros(nDepth,nPoint); 
stokesDepthYMatrix = zeros(nDepth,nPoint);
for indPoint=1:nPoint
    for indDepth=1:nDepth
        stokesDepthXMatrix(indDepth,indPoint) = deltaThetaValue * ...
            sum( cos(thetaVector) .* stokesStepArray(:,indDepth,indPoint) );
        stokesDepthYMatrix(indDepth,indPoint) = deltaThetaValue * ...
            sum( sin(thetaVector) .* stokesStepArray(:,indDepth,indPoint) );
    end
end
stokesMagnitudeMatrix = sqrt( stokesDepthXMatrix.^2 + ...
    stokesDepthYMatrix.^2 );
stokesDirectionMatrix = atan2( stokesDepthYMatrix, stokesDepthXMatrix );


%% 5. ADD NULL VALUES.

if exist('nullValue','var') == 1
    indNullCheck = find( stokesMagnitudeMatrix(1,:) == 0 )' ;
    nNull = length(indNullCheck) ;
    for indNull=1:nNull
        indNullPoint = indNullCheck(indNull) ;
        if spec2dArray3d(:,:,indNullPoint) == zeros(nFreq,nTheta)
            stokesMagnitudeMatrix(:,indNullPoint) = nullValue * ones(nDepth) ; 
            stokesDirectionMatrix(:,indNullPoint) = nullValue * ones(nDepth) ; 
        end
    end
end


%% 6. REBUILD ARRAY FOR OUTPUT.

stokesMagnitudeArray = subfnc_expand_dimension( stokesMagnitudeMatrix, 2, ...
    nDimension-1, rebuildVector, flgSpec2d);
stokesDirectionArray = subfnc_expand_dimension( stokesDirectionMatrix, 2, ...
    nDimension-1, rebuildVector, flgSpec2d);

if nDepth==1
    stokesMagnitudeArray = shiftdim( stokesMagnitudeArray, 1) ;
    stokesDirectionArray = shiftdim( stokesDirectionArray, 1) ;
end

%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_column_vector( varargin )

%% CHECK COLUMN VECTOR (SPECIFIC): 
%
% In:   'varargin'      Accepts any number of arguments in. Did not use
%                        the iscolumn command since it is not supported in
%                        older versions.


%% 1. VARIFY COLUMN VECTOR INPUT.

for ind=1:nargin
    if ( isvector(varargin{ind}) ~= 1 ) || ...
            ( size(varargin{ind},1) < length(varargin{ind}) )
        error([ 'Check input. Function requires vectors to be in ' ...
            'column form.' ])
    end
end    

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_freq_cutoff( freqVector, deltaFreqVector )

%% CHECK DELTA FREQUENCY CUTOFF (SPECIFIC): 
%
% In:   'freqVector'        Frequency bin values.
%       'deltaFreqVector'   Bandwidth of each frequency bin.


%% 1. ENSURE FINAL FREQUENCY VALUE FALLS ON RIGHT EDGE.

freqLength1 = freqVector(end) - freqVector(end-1);
freqLength2 = deltaFreqVector(end) + deltaFreqVector(end-1)/2;
if (freqLength2 - freqLength1)/freqLength1 > 0.05
    error(['The cutoff frequency bin value should fall on the right ' ...
        'edge. Check the final delta frequency value to ensure it is ' ...
        'not centered.'])
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [flgReshape,nDimension] = subfnc_check_orientation( ...
    spec2dArrayNd, nFreq, nTheta )

%% CHECK ARRAY ORIENATION OF 2D DIRECTIONAL-FREQUENCY SPECTRA (SPECIFIC): 
%
% In:   'spec2dArrayNd'     2D directional-frequency wave spectra with 
%                            dimensions [nFreq nTheta ... ...].
%       'nFreq'             Size of frequency bin.
%       'nTheta'            Size of theta bin.
%
% Out:  'flgReshape'        Flag indicates whether input array needs to be
%                            reshaped (1) or not (0). 
%       'nDimension'        Number of dimensions in 1D spectral array.


%% 1. CHECK DIMENSIONS AND ASSIGN FLAG.

nDimension = ndims(spec2dArrayNd); flgReshape = 0;

if nDimension == 1 
    error( 'The frequency-directional spectrum has a singleton dimension.')
elseif ( nDimension == 2 ) && ( min( size(spec2dArrayNd) ) == 1 )
    error([ 'The frequency or directional component has a singleton ' ...
        'dimension.' ])
elseif nDimension > 2
    flgReshape = 1; 
end


%% 2. VERIFY ORIENTATION OF ARRAY.

if size(spec2dArrayNd,1) ~= nFreq
    error([ 'The frequency spectrum must be the first dimension in ' ...
        'the 2D spectral input array.' ])
elseif size(spec2dArrayNd,2) ~= nTheta
    error([ 'The directional spectrum must be the second dimension in ' ...
        'the 2D spectral input array.' ])
end

for indDimension=2:nDimension
    if size(spec2dArrayNd,1) == size(spec2dArrayNd,indDimension)    
        disp(['Warning: Cannot determine if the array for the 2D ' ...
            'directional-frequency spectrum is orientated correctly. ' ...
            'Ensure the dimensions are [frequency, direction ... ...].' ])
        pause
    end
end

if nDimension >=3
    for indDimension=3:nDimension
        if size(spec2dArrayNd,2) == size(spec2dArrayNd,indDimension)    
            disp(['Warning: Cannot determine if the array for the 2D ' ...
                'directional-frequency spectrum is orientated ' ...
                'correctly. Ensure the dimensions are [frequency, ' ...
                'direction ... ...].' ])
            pause
        end
    end
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray, reshapeVector] = ...
    subfnc_reduce_dimension( inputArray, indMin, indMax, flgReshape )

%% REDUCE ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%
% Out:  'outputArray'       The reshaped array (for flag == 1).
%       'shapeVector'       Information containing old array dimensions.


%% 1. REDUCE DIMENSION OF ARRAY IF NECESSARY.

reshapeVector = [];

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nDimension = ndims(inputArray);
    if (indMin < 1) || (indMax > nDimension) || (indMax <= indMin) || ...
            (indMin == 1 && indMax == nDimension)
        error( 'Check dimension delimiters.')
    end
    for ind=1:nDimension
        inputLength{ind} = size( inputArray, ind );
    end
    indReshape = [];
    if indMin > 1
        for ind=1:indMin-1;
            indReshape = [indReshape inputLength{ind}];
        end
    end
    nPoint = 1;
    for ind=indMin:indMax
        nPoint = nPoint * inputLength{ind};
        reshapeVector = [reshapeVector inputLength{ind}];
    end    
    indReshape = [indReshape nPoint];
    if indMax < nDimension
        for ind=indMax+1:nDimension
            indReshape = [indReshape inputLength{ind}];
        end
    end
    outputArray = reshape( inputArray, indReshape );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray] = subfnc_expand_dimension( inputArray, indMin, ...
    indMax, reshapeVector, flgReshape )

%% EXPAND ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%       'reshapeVector'     Vector containing sizes of the new dimensions.
%
% Out:  'outputArray'       The reshaped array (for flag == 1).


%% 1. EXPAND DIMENSION OF ARRAY IF NECESSARY.

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nReshapeVector = length(reshapeVector);
    nDimensionInput = ndims(inputArray);
    if (nDimensionInput == 2) && ...
            (size(inputArray,2) == 1 || size(inputArray,1) == 1)
        nDimensionInput = 1;
    end

    nDimensionOutput = nDimensionInput + nReshapeVector - 1 ;
    
    if (indMin < 1) || ( indMax <= indMin ) || ...
            ( nReshapeVector ~= indMax-indMin+1 )
        error( 'Check dimension delimiters.')
    elseif ( size(inputArray,indMin) ~= prod(reshapeVector) ) 
        error( 'Number of elements in new array are not the same.')
    end
    
    for ind=1:nDimensionInput
        inputLength(ind) = size( inputArray, ind ) ;
    end

    expandVector = [];
    if indMin > 1
        for ind=1:indMin-1;
            expandVector = [expandVector size(inputArray,ind)] ;
        end
    end
    for ind=1:(indMax-indMin+1)
        expandVector = [expandVector reshapeVector(ind)] ;
    end
    if indMax < nDimensionOutput
        for ind=1:nDimensionOutput-indMax
            expandVector = [expandVector inputLength(ind+indMin)] ;
        end
    end
    outputArray = reshape( inputArray, expandVector );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sumStaticMatrix] = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector, depthVector, G )

%% SD STATIC SUM COMPONENTS (SPECIFIC): 
%   
% In:   'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin. 
%       'depthVector'       Depth is defined as ABS(z).
%       'G'                 Gravity constant.
%
% Out:  'sumStaticMatrix'   The static components of the 2Dh-SD sum.
%                             Dimensions are [sumStaticComponents,depth]. 


%% 1. CALCULATE STATIC SUM COMPONENTS.

INTEGRAND_CONSTANT = 16 * pi^3 / G;
nDepth = size(depthVector,1);
nFreq = size(freqVector,1);

betaMatrix = zeros(nFreq,nDepth);
for indDepth=1:nDepth
    betaMatrix(:,indDepth) = 8 * pi^2 / G * depthVector(indDepth) * ...
        freqVector.^2;
end

sumStaticMatrix = zeros(nFreq,nDepth);
for indDepth=1:nDepth
    sumStaticMatrix(:,indDepth) = INTEGRAND_CONSTANT * ...
        deltaFreqVector .* freqVector.^3 .* exp(-betaMatrix(:,indDepth));
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tailStaticVector] = subfnc_SD_tail_static( freqCutoff, ...
    depthVector, G )

%% SD STATIC TAIL COMPONENT (SPECIFIC): 
%
% In:   'freqCutoff'    The frequency cutoff is the last frequency value.
%       'depthVector'   Depth is defined as ABS(z).
%       'G'             Gravity constant.
%
% Out:  'tailStaticVector'  Static component of the SD tail calculation. 


%% 1. CALCULATE STATIC TAIL COMPONENT.

INTEGRAND_CONSTANT = 16 * pi^3 / G ;

alphaVector = 8 * pi^2 * depthVector / G ;
betaVector = alphaVector * freqCutoff^2 ;
erfcVector = 1 - erf( sqrt(betaVector) ) ;

tailStaticVector = INTEGRAND_CONSTANT * freqCutoff^4 * ...
    ( exp(-betaVector) - sqrt( pi * betaVector ) .* erfcVector ) ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
