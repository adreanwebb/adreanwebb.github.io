function [stokesIntegratedArray] = ...
    fnc_stokes_uni_magnitude_integrated (spec1dArray, freqVector, ...
    deltaFreqVector )

%% CALCULATE INTEGRATED-SD MAGNITUDE: 
% NOT CHANGED YET - UPDATE!!!
% This function uses 1D wave spectra with the unidirectional assumption to
% approximate the Stokes drift (SD) magnitude at some specified depth for
% an arbitrary number of spatial and temporal dimensions. 
% Created by Adrean Webb. 
%
% Requires: nothing.
%
% function [stokesDepthArray] = fnc_stokes_uni_magnitude ( ...
%    spec1dArray, freqVector, deltaFreqVector, depthVector )
%
% In:   'spec1dArray'       1D spectra with dimensions [nFreq ... ... ]. 
%       'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin.
%       'depthVector'       Depth is defined as ABS(z).
%
% Out:  'stokesIntegratedMatrix'    Integrated 1Dh-Uni-SD values with 
%                            dimensions [nDepth ... ...].
%
% Version: 1.1 [2012/11/5] - Expanded capability to handle an arbitrary 
%                             number of spatial and temporal dimensioins. 
%                             The script columnizes the extra dimensions in
%                             the 1D spectra and reshapes output to match.
%          1.2 [2012/11/5] - Changed script to run on older versions of
%                             Matlab less than 2011b.


%% 1. CHECK AND CONVERT INPUT IF NECESSARY.

if verLessThan('matlab','7.13')
    nargchk(3,3,nargin);
else    
    narginchk(3,3);
end

subfnc_check_column_vector(freqVector,deltaFreqVector);

subfnc_check_freq_cutoff(freqVector,deltaFreqVector);

nFreq = length(freqVector); 
flgSpec1d = subfnc_check_array(spec1dArray,nFreq);

[spec1dMatrix,rebuildVector] = subfnc_reduce_dimension(...
    spec1dArray,2,3,flgSpec1d);


%% 2. PRELIMINARY INITIALIZATION AND CALCULATIONS.

G = 9.81;

nPoint = size(spec1dMatrix,2);

stokesSumStaticVector = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector );
stokesTailStaticValue = subfnc_SD_tail_static( freqVector(end,1), G );


%% 3. CALCULATE INTEGRATED 1DH-UNI-SD.

stokesVector = zeros(nPoint,1);
for indPoint=1:nPoint
    stokesVector(indPoint) = sum( ...
        stokesSumStaticVector .* spec1dMatrix(:,indPoint) ) + ...
        stokesTailStaticValue * spec1dMatrix(end,indPoint);
end

stokesIntegratedArray = subfnc_expand_dimension(stokesVector,1,2,...
    rebuildVector,flgSpec1d);
    
%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_column_vector( varargin )

%% CHECK COLUMN VECTOR (SPECIFIC): 
%
% In:   'varargin'      Accepts any number of arguements in. Did not use
%                        the iscolumn command since it is not supported in
%                        older versions.


%% 1. VARIFY COLUMN VECTOR INPUT.

for ind=1:nargin
    if ( isvector(varargin{ind}) ~= 1 ) || ...
            ( size(varargin{ind},1) < length(varargin{ind}) )
        error([ 'Check input. Function requires vectors to be in ' ...
            'column form.' ])
    end
end    

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [flgReshape] = subfnc_check_array( spec1dArray, nFreq )

%% CHECK 1D SPECTRUM INPUT (SPECIFIC): 
%
% In:   'spec1dArray'   1D spectra array with frequency as the first
%                        dimension (the rest are location or time). 
%       'nFreq'         Size of frequency bin. 
% Out:  'flgReshape'    Flag indicates whether input array needs to be
%                        reshaped (1) or not (0). 


%% 1. VERIFY DIMENSIONS OF ARRAY.

nDimension = ndims(spec1dArray); flgReshape = 0;
if nDimension == 1 
    error( 'The frequency spectrum has a singleton dimension.')
elseif nDimension > 2
    flgReshape = 1;
elseif size(spec1dArray,1) ~= nFreq
    error([ 'The frequency spectrum must be the first dimension in ' ...
        'the 1D spectral input.' ])
end

for indDimension=2:nDimension
    if size(spec1dArray,1) == size(spec1dArray,indDimension)    
        disp(['Warning: Cannot determine if the matrix for the 1D ' ...
            'frequecny spectrum is orientated correctly. Ensure the ' ...
            'dimensions are [frequency, location].'])
        pause
    end
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray, reshapeVector] = ...
    subfnc_reduce_dimension( inputArray, indMin, indMax, flgReshape )

%% REDUCE ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%
% Out:  'outputArray'       The reshpaed array (for flag == 1).
%       'shapeVector'       Information containing old array dimensions.


%% 1. REDUCE DIMENSION OF ARRAY IF NECESSARY.

reshapeVector = [];

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nDimension = ndims(inputArray);
    if (indMin < 1) || (indMax > nDimension) || (indMax <= indMin) || ...
            (indMin == 1 && indMax == nDimension)
        error( 'Check dimension delimiters.')
    end
    for ind=1:nDimension
        inputLength{ind} = size( inputArray, ind );
    end
    indReshape = [];
    if indMin > 1
        for ind=1:indMin-1;
            indReshape = [indReshape inputLength{ind}];
        end
    end
    nPoint = 1;
    for ind=indMin:indMax
        nPoint = nPoint * inputLength{ind};
        reshapeVector = [reshapeVector inputLength{ind}];
    end    
    indReshape = [indReshape nPoint];
    if indMax < nDimension
        for ind=indMax+1:nDimension
            indReshape = [indReshape inputLength{ind}];
        end
    end
    outputArray = reshape( inputArray, indReshape );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray] = subfnc_expand_dimension( inputArray, indMin, ...
    indMax, reshapeVector, flgReshape )

%% EXPAND ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%       'reshapeVector'     Vector containing sizes of the new dimensions.
%
% Out:  'outputArray'       The reshpaed array (for flag == 1).


%% 1. EXPAND DIMENSION OF ARRAY IF NECESSARY.

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nReshapeVector = length(reshapeVector);
    nDimensionInput = ndims(inputArray);
    if (nDimensionInput == 2) && ...
            (size(inputArray,2) == 1 || size(inputArray,1) == 1)
        nDimensionInput = 1;
    end
    nDimensionOutput = nDimensionInput + nReshapeVector - 1;

    if (indMin < 1) || ( indMax <= indMin ) || ...
            ( nReshapeVector ~= indMax-indMin+1 )
        error( 'Check dimension delimiters.')
    elseif ( size(inputArray,indMin) ~= prod(reshapeVector) ) 
        error( 'Number of elements in new array are not the same.')
    end
    
    for ind=1:nDimensionInput
        inputLength(ind) = size( inputArray, ind );
    end

    expandVector = [];
    if indMin > 1
        for ind=1:indMin-1;
            expandVector = [expandVector size(inputArray,ind)];
        end
    end
    for ind=1:(indMax-indMin+1)
        expandVector = [expandVector reshapeVector(ind)];
    end
    if indMax < nDimensionOutput
        for ind=1:nDimensionOutput-indMax
            expandVector = [expandVector inputLength(ind+indMin)];
        end
    end
    outputArray = reshape( inputArray, expandVector );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_freq_cutoff( freqVector, deltaFreqVector )

%% CHECK DELTA FREQUENCY CUTOFF (SPECIFIC): 
%
% In:   'freqVector'        Frequency bin values.
%       'deltaFreqVector'   Bandwidth of each frequency bin.


%% 1. ENSURE FINAL FREQUENCY VALUE FALLS ON RIGHT EDGE.

freqLength1 = freqVector(end) - freqVector(end-1);
freqLength2 = deltaFreqVector(end) + deltaFreqVector(end-1)/2;
if (freqLength2 - freqLength1)/freqLength1 > 0.05
    error(['The cutoff frequncy bin value should fall on the right ' ...
        'edge. Check the final delta frequency value to ensure it is ' ...
        'not centered.'])
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sumStaticVector] = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector )

%% INTEGRATED SD STATIC SUM COMPONENTS (SPECIFIC): 
%   
% In:   'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin.
%
% Out:  'sumStaticVector'   The static components of the integrated 
%                             1Dh-Uni-SD sum vector. 


%% 1. CALCULATE STATIC SUM COMPONENTS.

INTEGRAND_CONSTANT = 2 * pi;

sumStaticVector = INTEGRAND_CONSTANT * deltaFreqVector .* freqVector ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tailStaticValue] = subfnc_SD_tail_static( freqCutoff, G )

%% SD STATIC TAIL COMPONENT (SPECIFIC): 
%
% In:   'freqCutoff'    The frequency cutoff is the last frequency value.
%       'G'             Gravity constant.
%
% Out:  'tailStaticValue'   Static component of the SD tail calculation. 


%% 1. CALCULATE STATIC TAIL COMPONENT.

INTEGRAND_CONSTANT = 2 * pi / 3;

tailStaticValue = INTEGRAND_CONSTANT * freqCutoff^2 ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

