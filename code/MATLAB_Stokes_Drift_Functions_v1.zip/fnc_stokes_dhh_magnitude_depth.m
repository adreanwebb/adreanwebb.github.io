function [stokesDepthArray] = fnc_stokes_dhh_magnitude_depth( ...
    spec1dArray, freqVector, deltaFreqVector, depthVector, nullValue )

%% CALCULATE 1DH-DHH-SD MAGNITUDE: 
% This function uses 1D wave spectra with the DHH directional-SD-component
% to approximate the Stokes drift (SD) magnitude at some specified depth
% for an arbitrary number of spatial and temporal dimensions. 
% Created by Adrean Webb. 
%
% Requires: nothing.
%
% function [stokesDepthArray] = fnc_stokes_dhh_magnitude_depth( ...
%    spec1dArray, freqVector, deltaFreqVector, depthVector, nullValue )
%
% In:   'spec1dArray'       1D spectra with dimensions [nFreq ... ... ]. 
%       'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin.
%       'depthVector'       Depth is defined as ABS(z).
%       'nullValue'         Specifies null return value for empty spectrum
%                             locations (variable input; default value 0).
%
% Out:  'stokesDepthArray'  1Dh-DHH-SD values with dimensions
%                            [nDepth ... ...].
%
% Version: 1.1 [2012/11/05] -   Expanded capability to handle an arbitrary 
%                                 number of spatial and temporal dimensions. 
%                               The script columnizes the extra dimensions in
%                                 the 1D spectra and reshapes output to match.
%          1.2 [2012/11/05] -   Changed script to run on older versions of
%                                 Matlab less than 2011b.
%          1.3 [2014/07/19] -   Fixed a bug introduced in Version 1.1 and added
%                                 null specification functionality.


%% 1. CHECK AND CONVERT INPUT IF NECESSARY.

if verLessThan('matlab','7.13')
    nargchk(4,5,nargin);
else    
    narginchk(4,5);
end

subfnc_check_column_vector( freqVector, deltaFreqVector, depthVector);

subfnc_check_freq_cutoff( freqVector, deltaFreqVector );

nFreq = length(freqVector);

flgSpec1d = subfnc_check_array( spec1dArray, nFreq );

[spec1dMatrix,rebuildVector] = subfnc_reduce_dimension( spec1dArray, 2, 3, ...
    flgSpec1d );


%% 2. PRELIMINARY INITIALIZATION AND CALCULATIONS.

G = 9.81;

nDepth = size(depthVector,1); nPoint = size(spec1dMatrix,2);

stokesSumStaticMatrix = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector, depthVector, G );
stokesTailStaticVector = subfnc_SD_tail_static( freqVector(end,1), ...
    depthVector, G );


%% 3. CALCULATE THE DHH DIRECTIONAL-SD-COMPONENT.

hMatrix = zeros(nFreq,nPoint);
for indPoint=1:nPoint
    [specPeak,indSpecPeak] = max( spec1dMatrix(:,indPoint) );
    if ( isnan(specPeak) ~= 1 )
        rVector = freqVector / freqVector(indSpecPeak);
        hMatrix(:,indPoint) = subfnc_SD_directional_component_DHH(rVector);
    else
        hMatrix(:,indPoint) = NaN;
    end
end


%% 4. CALCULATE DEPTH-DEPENDENT 1DH-DHH-SD.

stokesSumDynamicMatrix = hMatrix .* spec1dMatrix;

stokesDepthMatrix = zeros(nDepth,nPoint);
for indPoint=1:nPoint
    stokesTailVector = stokesTailStaticVector * ...
        stokesSumDynamicMatrix(end,indPoint);
    for indDepth=1:nDepth
        stokesDepthMatrix(indDepth,indPoint) = sum( ...
            stokesSumStaticMatrix(:,indDepth) .* ...
            stokesSumDynamicMatrix(:,indPoint) ) + ...
            stokesTailVector(indDepth);
    end
end


%% 5. ADD NULL VALUES.

if exist('nullValue','var') == 1
    indNullCheck = find( stokesDepthMatrix(1,:) == 0 )' ;
    nNull = length(indNullCheck) ;
    for indNull=1:nNull
        indNullPoint = indNullCheck(indNull) ;
        if spec1dMatrix(:,indNullPoint) == zeros(nFreq,1)
            stokesDepthMatrix(:,indNullPoint) = nullValue * ones(nDepth) ; 
        end
    end
end


%% 6. REBUILD ARRAY FOR OUTPUT.

stokesDepthArray = subfnc_expand_dimension(stokesDepthMatrix,2,3,...
    rebuildVector,flgSpec1d);

if nDepth==1
    stokesDepthArray = shiftdim( stokesDepthArray, 1) ;
end

%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_column_vector( varargin )

%% CHECK COLUMN VECTOR (SPECIFIC): 
%
% In:   'varargin'      Accepts any number of arguments in. Did not use
%                        the iscolumn command since it is not supported in
%                        older versions.


%% 1. VARIFY COLUMN VECTOR INPUT.

for ind=1:nargin
    if ( isvector(varargin{ind}) ~= 1 ) || ...
            ( size(varargin{ind},1) < length(varargin{ind}) )
        error([ 'Check input. Function requires vectors to be in ' ...
            'column form.' ])
    end
end    

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [flgReshape] = subfnc_check_array( spec1dArray, nFreq )

%% CHECK 1D SPECTRUM INPUT (SPECIFIC): 
%
% In:   'spec1dArray'   1D spectra array with frequency as the first
%                        dimension (the rest are location or time). 
%       'nFreq'         Size of frequency bin. 
% Out:  'flgReshape'    Flag indicates whether input array needs to be
%                        reshaped (1) or not (0). 


%% 1. VERIFY DIMENSIONS OF ARRAY.

nDimension = ndims(spec1dArray); flgReshape = 0;
if nDimension == 1 
    error( 'The frequency spectrum has a singleton dimension.')
elseif nDimension > 2
    flgReshape = 1;
elseif size(spec1dArray,1) ~= nFreq
    error([ 'The frequency spectrum must be the first dimension in ' ...
        'the 1D spectral input.' ])
end

for indDimension=2:nDimension
    if size(spec1dArray,1) == size(spec1dArray,indDimension)    
        disp(['Warning: Cannot determine if the matrix for the 1D ' ...
            'frequecny spectrum is orientated correctly. Ensure the ' ...
            'dimensions are [frequency, location].'])
        pause
    end
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray, reshapeVector] = ...
    subfnc_reduce_dimension( inputArray, indMin, indMax, flgReshape )

%% REDUCE ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%
% Out:  'outputArray'       The reshaped array (for flag == 1).
%       'shapeVector'       Information containing old array dimensions.


%% 1. REDUCE DIMENSION OF ARRAY IF NECESSARY.

reshapeVector = [];

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nDimension = ndims(inputArray);
    if (indMin < 1) || (indMax > nDimension) || (indMax <= indMin) || ...
            (indMin == 1 && indMax == nDimension)
        error( 'Check dimension delimiters.')
    end
    for ind=1:nDimension
        inputLength{ind} = size( inputArray, ind );
    end
    indReshape = [];
    if indMin > 1
        for ind=1:indMin-1;
            indReshape = [indReshape inputLength{ind}];
        end
    end
    nPoint = 1;
    for ind=indMin:indMax
        nPoint = nPoint * inputLength{ind};
        reshapeVector = [reshapeVector inputLength{ind}];
    end    
    indReshape = [indReshape nPoint];
    if indMax < nDimension
        for ind=indMax+1:nDimension
            indReshape = [indReshape inputLength{ind}];
        end
    end
    outputArray = reshape( inputArray, indReshape );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray] = subfnc_expand_dimension( inputArray, indMin, ...
    indMax, reshapeVector, flgReshape )

%% EXPAND ARRAY DIMENSION (GENERAL): 
%
% In:   'inputArray'        The array to be reshaped.
%       'indMin', 'indMax'  The dimension delimiters for reshaping. 
%       'flgReshape'        Flag == 0 / 1 indicates no action / action.
%       'reshapeVector'     Vector containing sizes of the new dimensions.
%
% Out:  'outputArray'       The reshaped array (for flag == 1).


%% 1. EXPAND DIMENSION OF ARRAY IF NECESSARY.

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nReshapeVector = length(reshapeVector);
    nDimensionInput = ndims(inputArray);
    nDimensionOutput = nDimensionInput + nReshapeVector - 1;
    
    if (indMin < 1) || ( indMax <= indMin ) || ...
            ( nReshapeVector ~= indMax-indMin+1 )
        error( 'Check dimension delimiters.')
    elseif ( size(inputArray,indMin) ~= prod(reshapeVector) ) 
        error( 'Number of elements in new array are not the same.')
    end
    
    for ind=1:nDimensionInput
        inputLength(ind) = size( inputArray, ind );
    end

    expandVector = [];
    if indMin > 1
        for ind=1:indMin-1;
            expandVector = [expandVector size(inputArray,ind)];
        end
    end
    for ind=1:(indMax-indMin+1)
        expandVector = [expandVector reshapeVector(ind)];
    end
    if indMax < nDimensionOutput
        for ind=1:nDimensionOutput-indMax
            expandVector = [expandVector inputLength(ind+indMin)];
        end
    end
    outputArray = reshape( inputArray, expandVector );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_freq_cutoff( freqVector, deltaFreqVector )

%% CHECK DELTA FREQUENCY CUTOFF (SPECIFIC): 
%
% In:   'freqVector'        Frequency bin values.
%       'deltaFreqVector'   Bandwidth of each frequency bin.


%% 1. ENSURE FINAL FREQUENCY VALUE FALLS ON RIGHT EDGE.

freqLength1 = freqVector(end) - freqVector(end-1);
freqLength2 = deltaFreqVector(end) + deltaFreqVector(end-1)/2;
if (freqLength2 - freqLength1)/freqLength1 > 0.05
    error(['The cutoff frequency bin value should fall on the right ' ...
        'edge. Check the final delta frequency value to ensure it is ' ...
        'not centered.'])
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hVector] = subfnc_SD_directional_component_DHH( rVector )

%% DHH DIRECTIONAL-SD-COMPONENT (SPECIFIC): 
%
% In:   'rVector'   'r' is defined as r = f/f_peak.
%
% Out:  'hVector'   'h' is the piecewise continuous DHH directional-SD-
%                     component.


%% 1. CREATE PIECEWISE CONTINUOUS H FUNCTION.

nR = size(rVector,1);

hVector = zeros(nR,1);
for ind=1:nR
    if ( rVector(ind) <= 0.56 )
        hVector(ind) = 0.777;
    end
    if ( rVector(ind) > 0.56 ) && ( rVector(ind) <= 0.95 )
        hVector(ind) = ...
            ( 0.52 - 3.3 * rVector(ind) + 8.9 * rVector(ind)^2) / ...
            ( 1 - 3.4 * rVector(ind) + 8.9 * rVector(ind)^2 );
    end    
    if ( rVector(ind) > 0.95 ) && ( rVector(ind) < 1.6 ) 
        hVector(ind) = ...
            ( 0.98 - 0.19 * rVector(ind) + 0.0058 * rVector(ind)^2) / ...
            ( 1 - 0.26 * rVector(ind) + 0.12 * rVector(ind)^2 );
    end    
    if ( rVector(ind) >= 1.6 )
        hVector(ind) = 0.777;
    end    
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sumStaticMatrix] = subfnc_SD_sum_static( freqVector, ...
    deltaFreqVector, depthVector, G )

%% SD STATIC SUM COMPONENTS (SPECIFIC): 
%   
% In:   'freqVector'        Frequency bin values (centered except for end).
%       'deltaFreqVector'   Bandwidth of each frequency bin.
%       'depthVector'       Depth is defined as ABS(z).
%       'G'                 Gravity constant.
%
% Out:  'sumStaticMatrix'   The static components of the 1Dh-DHH-SD sum.
%                             Dimensions are [sumStaticComponents,depth]. 


%% 1. CALCULATE STATIC SUM COMPONENTS.

INTEGRAND_CONSTANT = 16 * pi^3 / G;
nDepth = size(depthVector,1);
nFreq = size(freqVector,1);

betaMatrix = zeros(nFreq,nDepth);
for indDepth=1:nDepth
    betaMatrix(:,indDepth) = 8 * pi^2 / G * depthVector(indDepth) * ...
        freqVector.^2;
end

sumStaticMatrix = zeros(nFreq,nDepth);
for indDepth=1:nDepth
    sumStaticMatrix(:,indDepth) = INTEGRAND_CONSTANT * ...
        deltaFreqVector .* freqVector.^3 .* exp(-betaMatrix(:,indDepth));
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tailStaticVector] = subfnc_SD_tail_static( freqCutoff, ...
    depthVector, G )

%% SD STATIC TAIL COMPONENT (SPECIFIC): 
%
% In:   'freqCutoff'    The frequency cutoff is the last frequency value.
%       'depthVector'   Depth is defined as ABS(z).
%       'G'             Gravity constant.
%
% Out:  'tailStaticVector'  Static component of the SD tail calculation. 


%% 1. CALCULATE STATIC TAIL COMPONENT.

INTEGRAND_CONSTANT = 16 * pi^3 / G ;

alphaVector = 8 * pi^2 * depthVector / G ;
betaVector = alphaVector * freqCutoff^2 ;
erfcVector = 1 - erf( sqrt(betaVector) ) ;

tailStaticVector = INTEGRAND_CONSTANT * freqCutoff^4 * ...
    ( exp(-betaVector) - sqrt( pi * betaVector ) .* erfcVector ) ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
