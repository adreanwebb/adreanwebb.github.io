function [stokesIntegratedArrayNd] = fnc_stokes_uni_magnitude_integrated( ...
    spec1dArrayNd, freqVector, deltaFreqVector, nullValue )

%% FNC_STOKES_UNI_MAGNITUDE_INTEGRATED
%    This function uses 1D wave spectra (frequency) to calculate the depth-
%    integrated Stokes drift magnitude using an unidirectional wave assumption
%    (termed int-1Dh-SD). For $f \geq f_c$, the int-1Dh-SD spectral tail
%    contribution is calculated using the assumption 
%
%    $$ S_{f}(f) = (f_c/f)^5 S_{f}(f_c) $$, 
%
%    where '$f_c$' is the 'cutoff frequency' and '$S_{f}$' is the wave spectrum.
%    For simplicity, the final frequency bin value falls on the right edge
%    (versus center for others) and is the cutoff frequency. This function can
%    handle an arbitrary number of spatial and temporal dimensions. More
%    documentation can be found at <a href="www.adreanwebb.com">www.adreanwebb.com</a>. 
%
%    REQUIRES:    Matlab2008a or newer.
%
%    [stokesIntegratedArrayNd] = FNC_STOKES_UNI_MAGNITUDE_INTEGRATED( ...
%        spec1dArrayNd, freqVector, deltaFreqVector, nullValue )
%
%    IN:    'spec1dArrayNd'      1D frequency spectra with size [nFreq ... ...].
%           'freqVector'         Frequency bin column vector (centered except
%                                    for end). See 'subfnc_check_freq_cutoff'
%                                    for details.
%           'deltaFreqVector'    Frequency bin bandwidth column vector. 
%           'nullValue'          Specifies null return value for empty spectrum
%                                    locations (variable input; default 0).
%
%    OUT:    'stokesIntegratedArrayNd'    Int-1Dh-SD magnitude with size 
%                                             [... ...].      
%
%    VERSION:   1.0 [2014/03/21] - Created.
%               1.1 [2014/07/19] - Added null specification functionality.
%
%    See also FNC_STOKES_UNI_MAGNITUDE_DEPTH, ...
%        FNC_STOKES_MULTI_COMPONENTS_INTEGRATED, ...
%        FNC_STOKES_DHH_MAGNITUDE_INTEGRATED


%% 1. CHECK AND CONVERT INPUT IF NECESSARY.

if verLessThan('matlab','7.13'); nargchk(3,4,nargin); else narginchk(3,4); end

subfnc_check_column_vector( freqVector, deltaFreqVector );

subfnc_check_freq_cutoff( freqVector, deltaFreqVector );

nFreq = length(freqVector);

[flgSpec1d, nDimension] = subfnc_check_orientation( spec1dArrayNd, nFreq );

[spec1dMatrix, rebuildVector] = ...
    subfnc_reduce_dimension( spec1dArrayNd, 2, nDimension, flgSpec1d);


%% 2. PRELIMINARY INITIALIZATION AND CALCULATIONS.

nPoint = size(spec1dMatrix,2);

stokesSumStaticVector = subfnc_SD_sum_static( freqVector, deltaFreqVector );
stokesTailStaticValue = subfnc_SD_tail_static( freqVector(end,1) );


%% 3. CALCULATE INT-1DH-SD.

stokesIntegratedVector = zeros(nPoint,1);
for indPoint=1:nPoint
    stokesIntegratedVector(indPoint,1) = sum( ...
        stokesSumStaticVector .* spec1dMatrix(:,indPoint) ) + ...
        stokesTailStaticValue * spec1dMatrix(end,indPoint);
end


%% 4. ADD NULL VALUES IF NECESSARY.

if exist('nullValue','var') == 1
    indNullCheck = find( stokesIntegratedVector(:,1) == 0 )';
    nNull = length(indNullCheck);
    for indNull=1:nNull
        indNullPoint = indNullCheck(indNull);
        if spec1dMatrix(:,indNullPoint) == zeros(nFreq,1)
            stokesIntegratedVector(indNullPoint,1) = nullValue; 
        end
    end
end


%% 5. REBUILD ARRAY FOR OUTPUT.

stokesIntegratedArrayNd = subfnc_expand_dimension( ...
    stokesIntegratedVector, 1, nDimension-1, rebuildVector, flgSpec1d );
    
%%%%% END MAIN FUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_column_vector( varargin )

%% SUBFNC_CHECK_COLUMN_VECTOR (GENERIC) 
%    This subfunction checks to make sure input is a column vector.
%
%    REQUIRES:    Matlab 2008a or newer.
%
%    IN:    'varargin'    Accepts any number of arguments in. 


%% 1. VERIFY INPUT IS A COLUMN VECTOR.

for ind=1:nargin
    validateattributes( ...
        varargin{ind}, {'numeric'}, {'column'}, '', inputname(ind) );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subfnc_check_freq_cutoff( freqVector, deltaFreqVector )

%% SUBFNC_CHECK_FREQ_CUTOFF (SPECIFIC)
%    This subfunction checks to make sure the last frequency value falls on the
%    right edge.
%
%    IN:    'freqVector'         Frequency bin values.
%           'deltaFreqVector'    Bandwidth of each frequency bin.


%% 1. ENSURE FINAL FREQUENCY VALUE FALLS ON RIGHT EDGE.

freqLength1 = freqVector(end) - freqVector(end-1);
freqLength2 = deltaFreqVector(end) + deltaFreqVector(end-1)/2;
if (freqLength2 - freqLength1)/freqLength1 > 0.05
    error(['The cutoff frequency bin value should fall on the right ' ...
        'edge. Check the final delta frequency value to ensure it is ' ...
        'not centered.'])
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [flgReshape,nDimension] = ...
    subfnc_check_orientation( spec1dArrayNd, nFreq )

%% SUBFNC_CHECK_ORIENTATION (SPECIFIC) 
%    This subfunciton checks the array orientation of the 2D directional-
%    frequency spectra.
%
%    IN:    'spec1dArrayNd'    1D frequency spectra with size [nFreq ... ...].
%           'nFreq'            Size of frequency bin.
%
%    OUT:    'flgReshape'    Flag indicates whether input array needs to be
%                                reshaped (1) or not (0). 
%            'nDimension'    Number of dimensions in 1D spectral array.


%% 1. CHECK DIMENSIONS AND ASSIGN FLAG.

nDimension = ndims(spec1dArrayNd); flgReshape = 0;
if nDimension == 1 
    error( 'The frequency spectrum has a singleton dimension.')
elseif nDimension > 2
    flgReshape = 1;
elseif size(spec1dArrayNd,1) ~= nFreq
    error([ 'The frequency spectrum must be the first dimension in ' ...
        'the 1D spectral input.' ])
end

for indDimension=2:nDimension
    if size(spec1dArrayNd,1) == size(spec1dArrayNd,indDimension)    
        disp(['Warning: Cannot determine if the spectral array is oriented ' ...
            'correctly. Ensure size is [nFreq ... ...].'])
        pause
    end
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray, rebuildVector] = ...
    subfnc_reduce_dimension( inputArray, indMin, indMax, flgReshape )

%% SUBFNC_REDUCE_DIMENSION (GENERAL) 
%    This subfunction reduces the dimensions of an array. 
%
%    IN:    'inputArray'          The array to be reshaped.
%           'indMin', 'indMax'    The dimension delimiters for reshaping. 
%           'flgReshape'          Flag == 0 / 1 indicates no action / action.
%
%    OUT:    'outputArray'      The reshaped array (for flag == 1).
%            'rebuildVector'    Information containing old array dimensions.


%% 1. REDUCE DIMENSION OF ARRAY IF NECESSARY.

rebuildVector = [];

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nDimension = ndims(inputArray);
    if (indMin < 1) || (indMax > nDimension) || (indMax <= indMin) || ...
            (indMin == 1 && indMax == nDimension)
        error( 'Check dimension delimiters.')
    end
    
    inputLength = size(inputArray);
    indReshape = [];
    if indMin > 1
        indReshape = inputLength(1:indMin-1);
    end
    nPoint = 1;
    for ind=indMin:indMax
        nPoint = nPoint * inputLength(ind);
    end    
    indReshape = [indReshape nPoint];
    if indMax < nDimension
        indReshape = [indReshape inputLength(indMax+1:nDimension)];
    end
    outputArray = reshape( inputArray, indReshape );
    
    rebuildVector = inputLength(indMin:indMax);
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [outputArray] = subfnc_expand_dimension( ...
    inputArray, indMin, indMax, rebuildVector, flgReshape )

%% SUBFNC_EXPAND_DIMENSION (GENERAL) 
%    This subfunction expands the dimensions of an array. 
%
%    IN:    'inputArray'          The array to be reshaped.
%           'indMin', 'indMax'    The dimension delimiters for reshaping. 
%           'flgReshape'          Flag == 0 / 1 indicates no action / action.
%           'rebuildVector'       Vector containing sizes of the new dimensions.
%
%    OUT:    'outputArray'    The reshaped array (for flag == 1).


%% 1. EXPAND DIMENSION OF ARRAY IF NECESSARY.

if flgReshape == 0
    outputArray = inputArray;
elseif flgReshape == 1
    nRebuildVector = length(rebuildVector);
    nDimensionInput = ndims(inputArray);
    if (nDimensionInput == 2) && ...
            (size(inputArray,2) == 1 || size(inputArray,1) == 1)
        nDimensionInput = 1;
    end
    nDimensionOutput = nDimensionInput + nRebuildVector - 1;
    
    if (indMin < 1) || ( indMax <= indMin ) || ...
            ( nRebuildVector ~= indMax-indMin+1 )
        error( 'Check dimension delimiters.')
    elseif ( size(inputArray,indMin) ~= prod(rebuildVector) ) 
        error( 'Number of elements in new array are not the same.')
    end
    
    inputLength = size(inputArray);
    expandVector = [];
    if indMin > 1
        expandVector = [expandVector inputLength(1:indMin-1)];
    end
    expandVector = [expandVector rebuildVector( 1:(indMax-indMin+1) )];
    if indMax < nDimensionOutput
        expandVector = [expandVector ...
            inputLength( (1+indMin):(nDimensionOutput-indMax+indMin) )];
    end
    outputArray = reshape( inputArray, expandVector );
else
    error( 'Flag incorrectly assigned.' );
end

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sumStaticVector] = subfnc_SD_sum_static( freqVector, deltaFreqVector )

%% SUBFNC_SD_SUM_STATIC (SPECIFIC) 
%    This subfunction calculates the static components in the Stokes drift
%    summation.
%   
%    IN:    'freqVector'         Frequency bin values (centered except for end).
%           'deltaFreqVector'    Bandwidth of each frequency bin. 
%
%    OUT:    'sumStaticVector'    The static components of the int-1Dh-SD sum.
%                                     Size is [nFreq 1]. 


%% 1. CALCULATE STATIC SUM COMPONENTS.

INTEGRAND_CONSTANT = 2 * pi ;

sumStaticVector = INTEGRAND_CONSTANT * deltaFreqVector .* freqVector ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% START SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [tailStaticValue] = subfnc_SD_tail_static( freqCutoff )

%% SUBFNC_SD_TAIL_STATIC (SPECIFIC) 
%    This subfunction calculates the static components in the Stokes drift tail.
%
%    IN:    'freqCutoff'     The frequency cutoff is the last frequency value.
%
%    OUT:    'tailStaticValue'    Static component of the int-1Dh-SD tail
%                                     calculation. Returns a constant.


%% 1. CALCULATE STATIC TAIL COMPONENT.

INTEGRAND_CONSTANT = 2 * pi / 3;

tailStaticValue = INTEGRAND_CONSTANT * freqCutoff^2 ;

%%%%% END SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
